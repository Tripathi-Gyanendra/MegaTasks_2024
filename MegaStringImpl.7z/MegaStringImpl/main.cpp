#include <iostream>
#include "String.h"

using namespace mega;

void test_insert(mega::String& str)
{
    std::cout<<"\n********** Testing Insert() ********** \n\n";
    unsigned int initial_sz = str.Size();
    mega::String insertStr = "Not ";
    str.insert(14,insertStr);
    //std::cout<<"new string: "<<str;
	unsigned int total_size = initial_sz + insertStr.Size();
	if(total_size == str.Size())
		std::cout<<" ********* OK *********";
	else
		std::cout<<"********** Failed *********";
}

size_t test_find(mega::String& str)
{
    std::cout<<"********** Testing find() ********** \n\n";
    size_t pos = -2;

    mega::String searchStr = "Test";
    pos = str.find(searchStr);
	if(pos > 0)
		std::cout<<" ********* OK Found*********\n";
	else if(pos == String::npos)
		std::cout<<"********** Not Found *********\n";
	else
		std::cout<<"*********** Failed ************\n";
    /*TO-DO : test and invalid string pattern*/
    //mega::String searchStr = "Helljdjkjinndasdsadisadknadjnasdsjdhaodhsndnsa";
    //pos = str.find(searchStr);
    return pos;
}

void test_clear(mega::String& str)
{
    std::cout<<"********** Testing clear() ********** \n\n";
    str.clear();
    if(0 == str.Size())
		std::cout<<" ********* OK *********\n";
	else
		std::cout<<"********** Failed *********\n";
}

size_t test_size(mega::String& str)
{
    std::cout<<"********** Testing Size() ********** \n\n";
    size_t sz = str.Size();
	std::cout<<"size: "<<sz<<"\n";
    return sz;
}
void test_pushback(mega::String& str)
{
    std::cout<<"********** Testing pushback() ********** \n\n";
    mega::String str2 = " , OK ?";
    str.pushback(str2);
    std::cout<<"pushback result: "<<str <<"\n";
}

void test_popback(String& str)
{
    std::cout<<"********** Testing popback() ********** \n\n";
    str.popback();
	std::cout<<"after popback value: "<< str <<"\n";
}

int main()
{
    mega::String str = "Hello This is Test String";

    test_insert(str);
    std::cout<<"after inserting value: "<< str <<"\n";

    size_t pos = test_find(str);
    std::cout<<"pos: "<<pos<<"\n";

    size_t sz = test_size(str);
    

    test_pushback(str);
    

    test_popback(str);
    

    test_clear(str);
    size_t siz = test_size(str);
    std::cout<<"size after clear: "<<siz<<"\n";
    return 0;
}
