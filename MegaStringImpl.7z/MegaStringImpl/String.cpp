
#include <iostream>
#include <ostream>
#include "String.h"

//using namespace std;

using namespace mega;

    //buf = nullptr;
    //size = 0;

    const size_t String :: npos = -1;
	String:: String () : buf(nullptr), size(0) // default constructor
	{
        End_pos = nullptr;
        begin_itr = nullptr;
	}

	String :: String (const char* const buffer) // constructor
	{
        End_pos = nullptr;
        begin_itr = nullptr;
		size = strlen(buffer);
		buf = new char[size + 1]; // + 1 for the keeping the null character
		strncpy_s(buf, size + 1, buffer, size); // copy from the incoming buffer to character buffer of the new object
	}

    String :: String (const String& obj) // copy constructor
	{
		size = obj.size;
		buf = new char[size + 1]; // + 1 for the keeping the null character
		strncpy_s(buf, size + 1, obj.buf, size); // copy from the incoming buffer to character buffer of the new object
	}

    String& String :: operator=(const String& obj) // copy assignment
	{
		__cleanup__(); // cleanup any existing data

		// Copy data from the newly assigned my_string object
		size = obj.size;
		buf = new char[size + 1]; // + 1 for the keeping the null character
		strncpy_s(buf, size + 1, obj.buf, size); // copy from the incoming buffer to character buffer of the new object
		return *this;
	}

    String :: String (String&& dyingObj) // move constructor
	{
		__cleanup__(); // cleanup any existing data

		// Copy data from the incoming object
		size = dyingObj.size;
		
		// Transfer ownership of underlying char buffer from incoming object to this object
		buf = dyingObj.buf;
		dyingObj.buf = nullptr;		
	}

	String& String :: operator=(String&& dyingObj) // move assignment
	{
		__cleanup__(); // cleanup any existing data

		// Copy data from the incoming object
		size = dyingObj.size;

		// Transfer ownership of underlying char buffer from incoming object to this object
		buf = dyingObj.buf;
		dyingObj.buf = nullptr;

		return *this;
	}

	String String :: operator+(const String& obj) // concatenation
	{
		String s; // create a new string named 's'
		s.size = this->size + obj.size;
		s.buf = new char[s.size + 1]; // allocate memory to keep the concatenated string
		strncpy_s(s.buf, this->size + 1, this->buf, this->size); // copy the 1st string
		strncpy_s(s.buf + this->size, obj.size + 1, obj.buf, obj.size);

		return s;
	}

    unsigned int String :: Size()
	{
		return size;
	}

	const char * String :: c_str() const
	{
		return buf;
	}
	
	void String :: clear()
	{
		if(buf != nullptr)
		__cleanup__();
	}
	
	String :: ~String() // destructor
	{
		__cleanup__();
	}

	char* String :: begin() 
	{
        begin_itr = &buf[0];
        return begin_itr;
	}
	
    char* String :: End()
	{
        End_pos = &buf[size];
        return End_pos;
	}
	
	void String :: insert (int pos, String& obj)
	{
        String tempStrObj;
        tempStrObj.size = (this->size) - pos;
        tempStrObj.buf = new char[(tempStrObj.size) +1];
        strncpy(tempStrObj.buf, (this->buf + pos), tempStrObj.size);
		this->size = this->size + obj.size;
		char* tempBufPtr = this->buf;
		this->buf = new char[this->size + 1];
        strncpy(this->buf, tempBufPtr, (pos-1)+1); //copying starting bytes till pos.
		//strncpy_s(this->buf +pos, tempStrObj.buf, tempStrObj.size);
		int j = pos;// = pos;
		for(int i = 0; i < obj.size; i++)
		{
			this->buf[j] = obj.buf[i];
			j++;
		}
		//shifting data from position (old position was 'pos')
        for(int i =0; i < tempStrObj.size; i++)
		{
            this->buf[j] = tempStrObj.buf[i];
			j++;
		}
		
		delete[] tempBufPtr; //free old buffer memory
	}
	
	size_t String :: find(String& searchStrObj)
	{
		int searchStr_itr = 0;
		int mainStr_itr;
        size_t matchFlag = npos;
        size_t pos = npos;
		unsigned int mainStringBufSize = this->size;
        unsigned int searchStringBufSize = searchStrObj.size;
		int stringCapacity = (mainStringBufSize - searchStringBufSize);
        if(stringCapacity < 1)
		{
			std::cout<<"Error : invalid search string length \n";
			return pos;
		}
		for(mainStr_itr = 0; mainStr_itr <= stringCapacity; mainStr_itr++)
		{
			matchFlag = 0;
            if(searchStrObj.buf[searchStr_itr] == this->buf[mainStr_itr])
			{
				//std::cout<<"character matched \n";
				if (searchStr_itr == (searchStringBufSize - 1))
				{
					matchFlag = 1;
					break;
				}
				else
				{
					matchFlag = 1;
					searchStr_itr++;
				}
			}
			else {
				matchFlag = -1;
			}
		}
		if(matchFlag == 1)
		{
			//std::cout <<" i : "<<i<<" j: "<<j<<"\n";
			//std::cout<<"matching pos : "<<(mainStr_itr - searchStr_itr)<<"\n";
			pos = mainStr_itr - searchStr_itr;
		}
		return pos;
	}

    void String :: pushback(mega::String& str)
    {
		char* tempPtr = this->buf;
		this->buf = new char[this->size + str.size + 1];
		strncpy(this->buf, tempPtr, this->size); //copying existing string.
		strncpy( (this->buf)+(this->size), str.buf, str.size); //copying/adding new string.
		this->size = strlen(this->buf);
		delete[] tempPtr;
		
     }

    void String :: popback()
    {
		char* tempBufPtr;
		tempBufPtr = this->buf;
		this->buf = new char[(this->size) - 1];
		strncpy(this->buf, tempBufPtr, (this->size)-1);
		this->size = strlen(this->buf);
		delete[] tempBufPtr;
    }

