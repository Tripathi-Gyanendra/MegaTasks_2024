#ifndef MEGASTRING_H
#define MEGASTRING_H

#include <iostream>
#include <ostream>
#include <string.h>

/*
	Implementation of 'String' class under 'mega' namespace to 
	avoid any collision and to have a clean implementation. class name is 'String' to to avoid any confusion with existing class std::string.

*/

namespace mega
{
	
	class String
	{
		private:
		
			char * buf;
			unsigned int size;
            char* End_pos;
            char* begin_itr;
			
			inline void __cleanup__()
			{
				if (buf != nullptr)
				{
					std::cout<<"deleting buffer\n";
					delete[] buf;
				}
				std::cout<<"making size zero \n";
				size = 0;
			}
			
		public:

            static const size_t npos;
            typedef char* ITERATOR;
            static ITERATOR Iterator;

            String(); // default constructor

            String(const char * const buffer); // constructor


            String(const String & obj); // copy constructor


            String& operator=(const String & obj); // copy assignment

            String(String && dyingObj); // move constructor


            String& operator=(String && dyingObj); // move assignment


            String operator+(const String & obj); // concatenation


            unsigned int Size();


            const char * c_str() const;


            ~String(); // destructor

            char* begin();

            size_t find (String& searchStrObj);

            char* End();

            void insert(int pos, String& obj);

            void clear();

            void pushback(String& str);
            void popback();

            //typedef static char* iterator;
            //typedef Iterator iterator;
            friend std::ostream& operator<<(std::ostream& cout, const String & obj)
            {
                cout << obj.c_str();
                return cout;
            }
    };

}

#endif //MEGASTRING_H 
